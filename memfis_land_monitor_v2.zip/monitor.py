import os, sys, requests

USERNAME = "memfis_land"
TARGET = 1_399_900
ACTOR = "extractify-labs/instagram-com-follower-count-scraper"
APIFY_TOKEN = os.environ["APIFY_TOKEN"]
NTFY_TOPIC = os.environ["NTFY_TOPIC"]

def die(message):
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)

def main():
    url = f"https://api.apify.com/v2/acts/{ACTOR.replace('/', '~')}/run-sync-get-dataset-items"
    payload = {
        "usernames": [USERNAME],
        "maxItems": 1,
        "includePostsCount": False,
        "includeProfileDetails": False,
        "proxyConfiguration": {"useApifyProxy": False}
    }
    try:
        r = requests.post(url, params={"token": APIFY_TOKEN, "timeout": 240},
                          json=payload, timeout=250)
        r.raise_for_status()
        rows = r.json()
    except (requests.RequestException, ValueError) as e:
        die(f"Apify request failed: {e}")

    if not isinstance(rows, list) or len(rows) != 1:
        die(f"Expected one profile row; got {rows!r}")

    row = rows[0]
    if str(row.get("username", "")).lower().lstrip("@") != USERNAME:
        die(f"Unexpected profile returned: {row.get('username')!r}")

    count = row.get("followerCount")
    if isinstance(count, bool) or not isinstance(count, int) or count < 0:
        die(f"Invalid followerCount; fields returned: {sorted(row.keys())}")

    print(f"@{USERNAME}: {count:,} followers")
    if count < TARGET:
        print(f"Target not reached. Remaining: {TARGET-count:,}")
        return

    message = (f"پیج @{USERNAME} به حد هدف رسید یا از آن عبور کرد.\\n"
               f"تعداد ثبت‌شده: {count:,}\\nهدف: {TARGET:,}\\n"
               f"https://www.instagram.com/{USERNAME}/")
    try:
        n = requests.post(f"https://ntfy.sh/{NTFY_TOPIC}", data=message.encode(),
                          headers={"Title": "هشدار ممفیس لند",
                                   "Priority": "urgent", "Tags": "tada,instagram"},
                          timeout=30)
        n.raise_for_status()
    except requests.RequestException as e:
        die(f"ntfy notification failed: {e}")

    repo = os.environ.get("GITHUB_REPOSITORY")
    token = os.environ.get("GITHUB_TOKEN")
    if repo and token:
        try:
            d = requests.put(
                f"https://api.github.com/repos/{repo}/actions/workflows/monitor.yml/disable",
                headers={"Authorization": f"Bearer {token}",
                         "Accept": "application/vnd.github+json",
                         "X-GitHub-Api-Version": "2022-11-28"},
                timeout=30)
            d.raise_for_status()
            print("Workflow disabled after alert.")
        except requests.RequestException as e:
            print(f"WARNING: could not disable workflow: {e}", file=sys.stderr)

    print("TARGET REACHED — notification sent.")

if __name__ == "__main__":
    main()
