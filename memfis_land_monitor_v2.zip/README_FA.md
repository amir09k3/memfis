# مانیتور @memfis_land

تنظیمات:
- هدف: 1,399,900 فالوور یا بیشتر
- Actor: `extractify-labs/instagram-com-follower-count-scraper`
- فیلد خروجی: `followerCount` (عدد صحیح)
- بازه زمان‌بندی: هر ۵ دقیقه، با محدودیت تأخیر احتمالی GitHub Actions
- اعلان: ntfy روی اندروید

## راه‌اندازی
1. یک Topic تصادفی و طولانی در ntfy بساز و در اپ Subscribe کن. مجوز اعلان اندروید را فعال و محدودیت باتری ntfy را بردار.
2. در Apify Console از Settings → API & Integrations → API tokens یک API Token بساز. آن را فقط به‌عنوان Secret در GitHub ذخیره کن؛ هرگز در چت یا کد قرار نده.
3. یک مخزن **Private** در GitHub بساز و همه فایل‌های ZIP را با حفظ ساختار پوشه‌ها در ریشه مخزن بارگذاری کن.
4. در مخزن برو به Settings → Secrets and variables → Actions → New repository secret و این دو Secret را بساز:
   - `APIFY_TOKEN`: توکن Apify
   - `NTFY_TOPIC`: نام دقیق Topic در ntfy
5. در تب Actions، workflow با نام `Memfis Land follower monitor` را باز کن و Run workflow را برای تست دستی اجرا کن.
6. در لاگ اجرا بررسی کن که username و follower count درست چاپ شده باشند و اعلان آزمایشی ntfy را جداگانه تست کن.

## محدودیت‌ها
- طبق توضیحات Actor، `followerCount` شمارش دقیق عددی در زمان lookup است؛ با این حال سرویس ثالث ممکن است گاهی با محدودیت یا قطعی مواجه شود.
- GitHub Actions اجرای زمان‌بندی‌شده را دقیقاً سر هر ۵ دقیقه تضمین نمی‌کند. هشدار در اولین اجرای موفق پس از عبور از آستانه ارسال می‌شود، نه الزاماً همان لحظه.
- ۲۸۸ اجرا در روز ممکن است هزینه Apify ایجاد کند؛ پیش از فعال‌سازی دائم، هزینه هر اجرا و سهمیه حساب را بررسی کن.
- پس از ارسال موفق هشدار، workflow تلاش می‌کند خودش را غیرفعال کند تا هشدار تکراری ارسال نشود.
- رمز اینستاگرام، کوکی یا کد ورود را به Actor نده.
- Topic ntfy را محرمانه نگه دار؛ هرکس نام آن را بداند ممکن است بتواند برایش پیام بفرستد.
